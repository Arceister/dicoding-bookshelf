import { init } from "./server"

init()