import { BookTypeDefinition } from "../api/interface";

export const data: BookTypeDefinition[] = []